
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class UploadPage extends StatefulWidget {
  @override
  State<UploadPage> createState() => _UploadPageState();
}

class _UploadPageState extends State<UploadPage> {
  File? video;

  pickVideo() async {
    final picked = await ImagePicker().pickVideo(source: ImageSource.gallery);
    if (picked != null) setState(() => video = File(picked.path));
  }

  upload() async {
    final ref = FirebaseStorage.instance.ref('reels/${DateTime.now().millisecondsSinceEpoch}.mp4');
    await ref.putFile(video!);
    final url = await ref.getDownloadURL();
    await FirebaseFirestore.instance.collection('reels').add({'videoUrl': url});
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Upload Reel')),
      body: Column(
        children: [
          ElevatedButton(onPressed: pickVideo, child: Text('Pick Video')),
          ElevatedButton(onPressed: upload, child: Text('Upload')),
        ],
      ),
    );
  }
}
