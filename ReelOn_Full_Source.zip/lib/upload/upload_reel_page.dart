
import 'package:flutter/material.dart';

class UploadReelPage extends StatelessWidget {
  const UploadReelPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Upload Reel")),
      body: const Center(child: Text("Upload Reel Page")),
    );
  }
}
