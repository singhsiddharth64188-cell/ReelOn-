
class UploadService {
  Future<void> uploadReel() async {}
}
