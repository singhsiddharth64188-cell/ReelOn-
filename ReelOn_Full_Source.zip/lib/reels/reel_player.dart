
import 'package:flutter/material.dart';
import 'reel_model.dart';

class ReelPlayer extends StatelessWidget {
  final Reel reel;
  const ReelPlayer({super.key, required this.reel});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      child: Center(
        child: Text(
          reel.caption,
          style: const TextStyle(color: Colors.white, fontSize: 22),
        ),
      ),
    );
  }
}
