
import 'reel_model.dart';

class ReelController {
  List<Reel> getReels() {
    return [
      Reel(videoUrl: "", caption: "First Reel"),
      Reel(videoUrl: "", caption: "Second Reel"),
    ];
  }
}
