
import 'package:flutter/material.dart';
import 'reel_controller.dart';
import 'reel_player.dart';

class ReelFeedPage extends StatelessWidget {
  const ReelFeedPage({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = ReelController();
    final reels = controller.getReels();

    return Scaffold(
      body: PageView.builder(
        scrollDirection: Axis.vertical,
        itemCount: reels.length,
        itemBuilder: (context, index) {
          return ReelPlayer(reel: reels[index]);
        },
      ),
    );
  }
}
