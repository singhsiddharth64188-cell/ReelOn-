
class Reel {
  final String videoUrl;
  final String caption;

  Reel({required this.videoUrl, required this.caption});
}
