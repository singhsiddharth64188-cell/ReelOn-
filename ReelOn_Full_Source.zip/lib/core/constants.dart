
class AppConstants {
  static const appName = "ReelOn";
}
