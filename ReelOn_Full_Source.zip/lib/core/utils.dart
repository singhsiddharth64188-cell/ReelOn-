
class Utils {
  static String timeAgo(DateTime date) {
    return date.toIso8601String();
  }
}
