
import 'package:flutter/material.dart';
import 'core/theme.dart';
import 'reels/reel_feed_page.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ReelOnApp());
}

class ReelOnApp extends StatelessWidget {
  const ReelOnApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ReelOn',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkTheme,
      home: const ReelFeedPage(),
    );
  }
}
