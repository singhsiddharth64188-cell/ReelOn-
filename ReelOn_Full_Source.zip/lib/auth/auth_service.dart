
class AuthService {
  Future<void> signIn() async {}
  Future<void> signUp() async {}
  Future<void> signOut() async {}
}
